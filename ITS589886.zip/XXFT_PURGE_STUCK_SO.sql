 declare
        l_bulk_collect_limit              BINARY_INTEGER := 10000;
        L_COUNT_SO                        NUMBER;
        L_COUNT_INV                       NUMBER;
        l_final_count_so                  NUMBER;
        l_final_count_inv                 NUMBER;
        lv_msg  varchar2(32767);
        lv_msg1  varchar2(32767);
        dml_errors                        EXCEPTION;
        PRAGMA exception_init(dml_errors, -24381);
        l_errors                          NUMBER;
        l_errno                           NUMBER;
        l_msg                             VARCHAR2(4000);
        l_idx                             NUMBER;
        l_batch_id                        NUMBER;

         TYPE TAB_RPRO_INT_SO_STAGE_HIST IS TABLE OF RPRO_INT_SO_STAGE_HIST%ROWTYPE INDEX BY PLS_INTEGER;
         V_RPRO_INT_SO_STAGE_HIST_REC    TAB_RPRO_INT_SO_STAGE_HIST;--:= TAB_RPRO_INT_SO_STAGE_HIST ();

         TYPE TAB_RPRO_INT_INV_STAGE_HIST IS TABLE OF RPRO_INT_INV_STAGE_HIST%ROWTYPE INDEX BY PLS_INTEGER;
         V_RPRO_INT_INV_STAGE_HIST_REC   TAB_RPRO_INT_INV_STAGE_HIST;--:= TAB_RPRO_INT_INV_STAGE_HIST ();

         CURSOR C_SO
         is
            select * from RPRO_INT_SO_STAGE SOT
            WHERE  EXISTS (SELECT 1
                              FROM RPRO_ARR_TRANSACTIONS ARR
                             where ARR.SALES_ORDER_LINE_ID = SOT.SALES_ORDER_LINE_ID
                               --AND BATCH_ID = P_BATCH_ID
                               );

         CURSOR C_INV
         is
            SELECT * from RPRO_INT_INV_STAGE INVT
             WHERE  EXISTS (SELECT 1
                              FROM RPRO_ARR_TRANSACTIONS ARR
                             where ARR.INVOICE_LINE_ID = INVT.INVOICE_LINE_ID
                               --and BATCH_ID = P_BATCH_ID
                               );
    BEGIN

        APPS.fnd_file.put_line (  APPS.fnd_file.LOG,  'RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - INSIDE ARCHIVE SO' );

        rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','Inside Archive SO');

        OPEN C_SO;
        l_final_count_so := 0;
        LOOP
           FETCH C_SO
           BULK COLLECT INTO V_RPRO_INT_SO_STAGE_HIST_REC
           LIMIT l_bulk_collect_limit;

           L_COUNT_SO := V_RPRO_INT_SO_STAGE_HIST_REC.COUNT;

           IF NVL(L_COUNT_SO,0) = 0 THEN
           EXIT;
           END IF;


           BEGIN
                FORALL i IN V_RPRO_INT_SO_STAGE_HIST_REC.FIRST ..
                  V_RPRO_INT_SO_STAGE_HIST_REC.LAST SAVE EXCEPTIONS
                INSERT INTO RPRO_INT_SO_STAGE_HIST VALUES V_RPRO_INT_SO_STAGE_HIST_REC (i);

           EXCEPTION
             WHEN DML_ERRORS THEN
              l_errors := SQL%bulk_exceptions.COUNT;
              FOR I in 1 .. l_errors
              LOOP
                l_errno := SQL%bulk_exceptions(i).error_code;
                l_msg   := sqlerrm(-l_errno);
                l_idx   := SQL%bulk_exceptions(i).error_index;

              APPS.fnd_file.put_line (  APPS.fnd_file.LOG,  'EXCEPTION @ RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - ARCHIVE SO' ||l_idx ||':'|| substr(l_msg,1,255));

              rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','EXCEPTION @ RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - ARCHIVE SO' ||l_idx ||':'|| substr(l_msg,1,255));
              END LOOP;
           END;

           BEGIN
                FOR J IN V_RPRO_INT_SO_STAGE_HIST_REC.FIRST ..
                V_RPRO_INT_SO_STAGE_HIST_REC.LAST LOOP

                    DELETE FROM RPRO_INT_SO_STAGE WHERE sales_order_line_id = V_RPRO_INT_SO_STAGE_HIST_REC(J).sales_order_line_id;
                END LOOP;
           EXCEPTION
                WHEN OTHERS THEN
                    rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','EXCEPTION while deleting rpro_int_so_stage '|| substr(sqlerrm,1,200) );
           END;

           COMMIT;

           V_RPRO_INT_SO_STAGE_HIST_REC.DELETE;
            l_final_count_so := l_final_count_so + l_count_so;
           EXIT WHEN C_SO%NOTFOUND;
        END LOOP;

        CLOSE C_SO;

        COMMIT;

        rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','COMPLETED ARCHIVING SO' );

        APPS.fnd_file.put_line (  APPS.fnd_file.LOG,  'RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - COMPLETED ARCHIVING SO');

     -- Completed SO Archive

     -- Begin INV Archive
     --Insert INV Data from INV Stage to INV History table

        OPEN C_INV;
          l_final_count_inv :=0 ;
        LOOP

            rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','INSIDE ARCHIVE INV' );

            APPS.fnd_file.put_line (  APPS.fnd_file.LOG,  'RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - INSIDE ARCHIVE INV');

           FETCH C_INV
           BULK COLLECT INTO V_RPRO_INT_INV_STAGE_HIST_REC
           LIMIT l_bulk_collect_limit;

           L_COUNT_INV := V_RPRO_INT_INV_STAGE_HIST_REC.COUNT;

           IF NVL(L_COUNT_INV,0) = 0 THEN
           EXIT;
           END IF;


           BEGIN
                FORALL i IN V_RPRO_INT_INV_STAGE_HIST_REC.FIRST ..
                  V_RPRO_INT_INV_STAGE_HIST_REC.LAST SAVE EXCEPTIONS

                    INSERT INTO RPRO_INT_INV_STAGE_HIST VALUES V_RPRO_INT_INV_STAGE_HIST_REC (i);

           EXCEPTION
           WHEN DML_ERRORS THEN
              l_errors := SQL%bulk_exceptions.COUNT;
              FOR I in 1 .. l_errors
              LOOP
                l_errno := SQL%bulk_exceptions(i).error_code;
                l_msg   := sqlerrm(-l_errno);
                l_idx   := SQL%bulk_exceptions(i).error_index;

                rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','EXCEPTION @ RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - ARCHIVE INV' ||l_idx ||':'|| substr(l_msg,1,255));

                APPS.fnd_file.put_line (  APPS.fnd_file.LOG,  'EXCEPTION @ RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - ARCHIVE INV' ||l_idx ||':'|| substr(l_msg,1,255));

              END LOOP;
           END;

           BEGIN
                FOR j IN V_RPRO_INT_INV_STAGE_HIST_REC.FIRST ..
                V_RPRO_INT_INV_STAGE_HIST_REC.LAST LOOP

                DELETE FROM RPRO_INT_INV_STAGE WHERE INVOICE_LINE_ID = V_RPRO_INT_INV_STAGE_HIST_REC(j).invoice_line_id;

                END LOOP;
           EXCEPTION
                WHEN OTHERS THEN
                    rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','EXCEPTION while deleting rpro_int_inv_stage ' || substr(sqlerrm,1,200));
           END;


           V_RPRO_INT_INV_STAGE_HIST_REC.DELETE;
            l_final_count_inv := l_final_count_inv + l_count_inv;

           EXIT WHEN C_INV%NOTFOUND;
        END LOOP;

       COMMIT;

        CLOSE C_INV;

        rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','COMPLETED ARCHIVE INV');

        APPS.fnd_file.put_line (  APPS.fnd_file.LOG,  'RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR - COMPLETED ARCHIVING INV');


    EXCEPTION
      WHEN OTHERS THEN
        rpro_int_log_pkg.record_log ( l_batch_id, 'RPRO_POST_PROCESSOR','EXCEPTION @ RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR' ||l_idx ||':'|| substr(l_msg,1,255));

        APPS.fnd_file.put_line (  APPS.fnd_file.LOG,  'EXCEPTION @ RPRO_DATA_LOAD_TO_STG_PKG.RPRO_POST_PROCESSOR' || substr(sqlerrm,1,150));
    END;