/*******************************************************************************
*
*  File : XXFT_RESET_Grace_Period_FIX.sql.
*  
*  Date        Created By           Comments
*  ******      ************         ********************
*  23-SEP-16   Sai Kondamuru        Reset the Grace period change transactions to 'N'.
*                                   ITS#589886

* 
******************************************************************************/

--
-- Number of transactions before interface.
--
select count(1) from XXFT.XXFT_RPRO_GRACE_PD_CHG_DETAILS where processed_flag='P';

--
-- Update the transactions to 'N'
--
Update XXFT.XXFT_RPRO_GRACE_PD_CHG_DETAILS
set processed_flag='N'
   ,last_update_date = sysdate
   ,request_id = null
where processed_flag ='P';

commit;